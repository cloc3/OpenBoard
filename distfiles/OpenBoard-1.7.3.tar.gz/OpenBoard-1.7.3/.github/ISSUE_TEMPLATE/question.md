---
name: Question
about: If you simply have a question related to OpenBoard
title: "[Question]"
labels: 'question'
assignees: ''

---

