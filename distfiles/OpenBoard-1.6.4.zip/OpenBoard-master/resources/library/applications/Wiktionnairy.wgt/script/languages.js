﻿var sankoreLang = {
    "en":{
        "wikipedia": "Wiktionary",
        "prev_word":"Previous word",
        "next_word":"Next word",
        "search":"Search"
    },
    "ru":{
        "wikipedia": "Викисловарь",
        "prev_word":"Пред. слово",
        "next_word":"След. слово",
        "search":"Поиск"
    },
    "fr":{
        "wikipedia": "Wiktionnaire",
        "prev_word":"Mot précédent",
        "next_word":"Mot suivant",
        "search":"Rechercher"
    },
    "sk":{
        "wikipedia": "Wikislovník",
        "prev_word":"Predošlé slovo",
        "next_word":"Ďalšie slovo",
        "search":"Vyhľadať"
    }

};

