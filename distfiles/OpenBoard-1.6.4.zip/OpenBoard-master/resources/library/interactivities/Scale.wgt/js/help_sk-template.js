﻿<h3>Váha</h3>
<h4>Rovnaká hmotnosť, počítanie spamäti</h4>
 
<p>Na ľavú misku váhy treba dať toľko závaží, aby na nej bola rovnaká hmotnosť ako na pravej miske.</p>
<p>Závažie na ľavú misku pridáte tak, že naň kliknete a&nbsp;presuniete ho tam.</p>
 
<p>Možnosti riešenia si môžu žiaci zapísať na tabuľu alebo ich môžu vyskúšať priamo na váhe.</p>
<p>Tlačidlom „Obnoviť“ odoberiete z ľavej misky váhy všetky závažia.</p>
 
<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav zmeniť:</p>
<ul><li> farebný motív na tablet, bridlicu alebo na žiadny (predvolený je tablet),</li>
<li>počet závaží na pravej miske váhy,</li>
<li>hmotnosť závaží, ktoré budú žiaci dokladať na ľavú misku váhy.</li></ul>

<p>Ak chcete presunúť závažie na pravú misku váhy, kliknite naň a&nbsp;presuňte ho tam.</p>
<p>Ak chcete pridať ďalšie závažie, kliknite na tlačidlo „+“ a&nbsp;zadajte hmotnosť závažia. (Nepoužívajte desatinné čísla.)</p>
<p>Každé závažie má číselné pole. Kliknite na toto pole a&nbsp;zadajte doň príslušné číslice.</p>
<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>
