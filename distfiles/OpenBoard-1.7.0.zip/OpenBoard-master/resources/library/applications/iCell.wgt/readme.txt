-------------------------------------------------------------------------
--------		iCell par Sidney Bovet			---------
-------------------------------------------------------------------------

D�marche pour acc�der au widget depuis Uniboard 4
(impossible depuis les versions ult�rieures):


	- Copier/Coller le dossier 'Cellule.wgt' dans le dossier
	  \Uniboard 4\library\interactive\Cellule.wgt

	- Depuis Uniboard 4: cliquez sur 'Biblioth�que' puis, sous
	  l'onglet interactif, glissez l'icone du widget sur la page



Licence:

Ce travail est mis � disposition sous une licence CreativeCommons BY-NC-SA.

Ceci implique que vous �tes libre de copier, de distribuer et/ou de modifier ce travail � votre guise, sous les conditions suivantes:

- Ce travail ne peut en aucun cas �tre utilis� dans un cadre commercial

- Si vous transformez ce travail ou en cr�ez un ayant celui-ci pour base, vous �tes tenu de diffuser le r�sultat sous la m�me licence que iCell

- De plus, au d�but ou � la fin du nouveau travail doit figurer le nom de l'auteur originel ainsi que les sources qu'il a lui-m�me cit�

-------------------------------------------------------------------------
--------			GYB - 2010			---------
-------------------------------------------------------------------------