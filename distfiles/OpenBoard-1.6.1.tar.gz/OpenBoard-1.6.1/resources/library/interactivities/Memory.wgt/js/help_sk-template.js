﻿<h3>Pexeso</h3>
<h4>Počítanie spamäti, pexeso</h4>
<p>Cieľom hry Pexeso je zapamätať si umiestnenie rôznych kariet a nájsť ich dvojice.</p>
<p>Karty sú rozmiestnené v mriežke a&nbsp;o&shy;točené lícom nadol. 
Hráč si zvolí dve karty. Ak sú rovnaké, zostanú otočené lícom nahor. 
Ak nie sú rovnaké, znova sa otočia lícom nadol.</p>
<p>Hra sa končí, keď hráč nájde všetky dvojice.</p>

<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav:</p>
<ul>
<li>zmeniť farebný motív na bridlicu, tablet alebo na žiadny (predvolená je bridlica),</li>
<li>zvoliť si počet kariet (4 karty, 6 alebo 8 kariet),</li>
<li>nastaviť čas zobrazenia kariet,</li>
<li>zmeniť obsah kariet.</li>
</ul>
<p>Každá karta má textové pole. Ak chcete zadať text, kliknite naň.</p>
<p>Ak chcete pridať obrázok z knižnice, zaškrtnite položku „Obrázok“, kliknite na obrázok a presuňte ho do karty.</p>
<p>V hre sú karty usporiadané náhodne.</p>
<p>Aplikácia dokáže rozoznať matematický zápis &ndash; povolené znamienka:  „+“, „*“ (krát), „-“, „/“ (delené) a&nbsp;zátvorky. Vyhnite sa však deleniu 0.</p>
<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>
