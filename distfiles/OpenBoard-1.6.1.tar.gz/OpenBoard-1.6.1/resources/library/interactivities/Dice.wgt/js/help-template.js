<h3>Dices</h3>
<h4>For oral calculation or for various games</h4>

<p>The dices interactivity allows you to display random dices faces.</p>
<p>By clicking on the arrow or on "Launch" button, you have a new set of results. You can work the oral calculation with the displayed results or play to "the account is good".</p>
<p>The calculations and reasoning can be written on the white board (outside the App).</p>
<p>Enter the "Edit" mode to :</p>
<ul>
<li>choose the theme of the App : pad, slate, or none (by default : pad),</li>
<li>determine the number of dices you want to use for your activity (1-6).</li>
</ul>
<p>The calculations and reasoning could be written on the page (outside the App).</p>
<p>"Display" button comes back to the activity.</p>