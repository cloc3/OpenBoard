﻿var sankoreLang = {
    "en":{
        "embed": "Embed"
    },
    "ru":{
        "embed": "Вставить"
    },
    "fr":{
        "embed": "Intégrer"
    },
    "sk":{
        "embed": "Vložiť"
    }
};
