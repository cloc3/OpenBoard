﻿var sankoreLang = {
    "en":{
        "show": "Show"
    },
    "ru":{
        "show": "Смотреть"
    },
    "fr":{
        "show": "Voir"
    },
    "sk":{
        "show": "Zobraziť"
    }

};

