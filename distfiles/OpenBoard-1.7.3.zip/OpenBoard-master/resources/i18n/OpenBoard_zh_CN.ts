<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>BlackoutWidget</name>
    <message>
        <location filename="../forms/blackoutWidget.ui" line="156"/>
        <source>Click to Return to Application</source>
        <translation>点击返回到应用程序</translation>
    </message>
</context>
<context>
    <name>BrowserWindow</name>
    <message>
        <location filename="../../src/web/simplebrowser/browserwindow.cpp" line="151"/>
        <source>Navigation</source>
        <translation>导航</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/browserwindow.cpp" line="179"/>
        <source>Show downloads</source>
        <translation>显示下载</translation>
    </message>
</context>
<context>
    <name>CertificateErrorDialog</name>
    <message>
        <location filename="../../src/web/simplebrowser/certificateerrordialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/certificateerrordialog.ui" line="26"/>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/certificateerrordialog.ui" line="42"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/certificateerrordialog.ui" line="61"/>
        <source>If you wish so, you may continue with an unverified certificate. Accepting an unverified certificate mean you may not be connected with the host you tried to connect to.

Do you wish to override the security check and continue ?   </source>
        <translation>如果愿意，您可以继续使用未经验证的证书。接受未经验证的证书意味着您可能无法连接到想要连接的主机。

是否希望跳过安全检查并继续？</translation>
    </message>
</context>
<context>
    <name>DownloadManagerWidget</name>
    <message>
        <location filename="../../src/web/simplebrowser/downloadmanagerwidget.ui" line="14"/>
        <source>Downloads</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadmanagerwidget.ui" line="89"/>
        <source>No downloads</source>
        <translation>不下载</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadmanagerwidget.cpp" line="82"/>
        <source>Save as</source>
        <translation>另存为</translation>
    </message>
</context>
<context>
    <name>DownloadWidget</name>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.ui" line="31"/>
        <location filename="../../src/web/simplebrowser/downloadwidget.ui" line="71"/>
        <source>TextLabel</source>
        <translation>文字标签</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="87"/>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="127"/>
        <source>Open file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="137"/>
        <source>%L1 B</source>
        <translation>%L1 B</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="139"/>
        <source>%L1 KiB</source>
        <translation>%L1 KB</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="141"/>
        <source>%L1 MiB</source>
        <translation>%L1 MB</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="143"/>
        <source>%L1 GiB</source>
        <translation>%L1 GB</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="168"/>
        <source>%p% - %1 of %2 downloaded - %3/s</source>
        <translation>%p% - 已下载 %1 , 共 %2 - %3/s</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="176"/>
        <source>unknown size - %1 downloaded - %2/s</source>
        <translation>未知大小 - 已下载 %1 - %2/s</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="185"/>
        <source>completed - %1 downloaded - %2/s</source>
        <translation>已完成 - 已下载 %1 - %2/s</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="194"/>
        <source>cancelled - %1 downloaded - %2/s</source>
        <translation>已取消 - 已下载 %1 - %2/s</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="202"/>
        <source>interrupted: %1</source>
        <translation>已中断：%1</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="210"/>
        <source>Stop downloading</source>
        <translation>停止下载</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/downloadwidget.cpp" line="214"/>
        <source>Remove from list</source>
        <translation>从列表中删除</translation>
    </message>
</context>
<context>
    <name>IntranetPodcastPublishingDialog</name>
    <message>
        <source>Publish Podcast to YouTube</source>
        <translation type="vanished">发布播客到 Youtube</translation>
    </message>
    <message>
        <location filename="../forms/intranetPodcastPublishingDialog.ui" line="17"/>
        <source>Publish to Intranet</source>
        <translation type="unfinished">发布到内网</translation>
    </message>
    <message>
        <location filename="../forms/intranetPodcastPublishingDialog.ui" line="28"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../forms/intranetPodcastPublishingDialog.ui" line="42"/>
        <source>Description</source>
        <translation>详情</translation>
    </message>
    <message>
        <location filename="../forms/intranetPodcastPublishingDialog.ui" line="65"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/mainWindow.ui" line="43"/>
        <location filename="../forms/mainWindow.ui" line="657"/>
        <source>Board</source>
        <translation>白板</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="97"/>
        <location filename="../forms/mainWindow.ui" line="340"/>
        <source>Web</source>
        <translation>网页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="147"/>
        <location filename="../forms/mainWindow.ui" line="320"/>
        <source>Documents</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="203"/>
        <location filename="../forms/mainWindow.ui" line="206"/>
        <source>Stylus</source>
        <translation>工具面板</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="214"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="226"/>
        <source>Backgrounds</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="229"/>
        <source>Change Background</source>
        <translation>更换背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="243"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="251"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="260"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="268"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="277"/>
        <source>Previous</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="280"/>
        <location filename="../forms/mainWindow.ui" line="567"/>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="288"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="297"/>
        <source>Next</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="300"/>
        <location filename="../forms/mainWindow.ui" line="587"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="308"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <source>Manage Documents</source>
        <translation type="vanished">管理文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="331"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <source>Web Browsing</source>
        <translation type="vanished">浏览网页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="351"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="366"/>
        <location filename="../forms/mainWindow.ui" line="381"/>
        <location filename="../forms/mainWindow.ui" line="396"/>
        <location filename="../forms/mainWindow.ui" line="1567"/>
        <source>Line</source>
        <translation>线条</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="369"/>
        <source>Small Line</source>
        <translation>细</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="384"/>
        <source>Medium Line</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="399"/>
        <source>Large Line</source>
        <translation>粗</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="408"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="429"/>
        <location filename="../forms/mainWindow.ui" line="447"/>
        <location filename="../forms/mainWindow.ui" line="462"/>
        <location filename="../forms/mainWindow.ui" line="1449"/>
        <source>Eraser</source>
        <translation>橡皮擦</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="450"/>
        <source>Medium Eraser</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="465"/>
        <source>Large Eraser</source>
        <translation>大</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="564"/>
        <source>Back</source>
        <translation>后退</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="575"/>
        <source>Left</source>
        <translation>向左</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="584"/>
        <source>Forward</source>
        <translation>前进</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="595"/>
        <source>Right</source>
        <translation>向右</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="604"/>
        <source>Reload</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="607"/>
        <source>Reload Current Page</source>
        <translation>重新加载当前页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="621"/>
        <source>Home</source>
        <translation>主页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="624"/>
        <source>Load Home Page</source>
        <translation>加载主页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="633"/>
        <source>Bookmarks</source>
        <translation>书签</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="636"/>
        <source>Show Bookmarks</source>
        <translation>显示书签</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="645"/>
        <source>Bookmark</source>
        <translation>书签</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="648"/>
        <source>Add Bookmark</source>
        <translation>添加书签</translation>
    </message>
    <message>
        <source>Display Board</source>
        <translation type="vanished">显示白板</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="668"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="680"/>
        <source>Erase</source>
        <translation>清除页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="683"/>
        <source>Erase Content</source>
        <translation>清除内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="697"/>
        <source>Preferences</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="700"/>
        <source>Display Preferences</source>
        <translation>显示参数设置</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="712"/>
        <source>Library</source>
        <translation>库</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="715"/>
        <source>Show Library</source>
        <translation>显示库</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="718"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="750"/>
        <source>Show Desktop</source>
        <translation>显示桌面</translation>
    </message>
    <message>
        <source>Show Computer Desktop</source>
        <translation type="vanished">显示电脑桌面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="764"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="773"/>
        <source>Bigger</source>
        <translation>更大</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="776"/>
        <location filename="../forms/mainWindow.ui" line="1522"/>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="784"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="793"/>
        <source>Smaller</source>
        <translation>更小</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="796"/>
        <location filename="../forms/mainWindow.ui" line="1535"/>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="804"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="813"/>
        <source>New Folder</source>
        <translation>新建文件夹</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="816"/>
        <source>Create a New Folder</source>
        <translation>创建一个新文件夹</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="830"/>
        <source>New Document</source>
        <translation>新建文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="833"/>
        <source>Create a New Document</source>
        <translation>创建一个新文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="847"/>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="850"/>
        <source>Import a Document</source>
        <translation>导入文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="864"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="867"/>
        <source>Export a Document</source>
        <translation>导出文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="881"/>
        <source>Open in Board</source>
        <translation>在白板中打开</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="884"/>
        <source>Open Page in Board</source>
        <translation>在白板中打开页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="892"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="901"/>
        <source>Duplicate</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="904"/>
        <source>Duplicate Selected Content</source>
        <translation>复制所选内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="918"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="921"/>
        <source>Delete Selected Content</source>
        <translation>删除所选内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="929"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Add to Working Document</source>
        <translation type="vanished">添加到工作文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="941"/>
        <source>Add Selected Content to Open Document</source>
        <translation>添加所选内容到打开的文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="955"/>
        <location filename="../forms/mainWindow.ui" line="1414"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="958"/>
        <source>Add Content to Document</source>
        <translation>添加内容到文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="972"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="975"/>
        <source>Rename Content</source>
        <translation>重命名内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="992"/>
        <location filename="../forms/mainWindow.ui" line="1007"/>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="995"/>
        <location filename="../forms/mainWindow.ui" line="1010"/>
        <source>Display Tools</source>
        <translation>显示工具</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1030"/>
        <source>Multi Screen</source>
        <translation>多屏显示</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1042"/>
        <location filename="../forms/mainWindow.ui" line="1045"/>
        <source>Wide Size (16/9)</source>
        <translation>宽屏尺寸（16/9）</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1048"/>
        <source>Use Document Wide Size (16/9)</source>
        <translation>使用宽屏显示文档（16/9）</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1063"/>
        <location filename="../forms/mainWindow.ui" line="1066"/>
        <source>Regular Size (4/3)</source>
        <translation>标准尺寸（4/3）</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1069"/>
        <source>Use Document Regular Size (4/3)</source>
        <translation>使用标准屏幕显示文档（4/3）</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1087"/>
        <location filename="../forms/mainWindow.ui" line="1090"/>
        <source>Custom Size</source>
        <translation>自定义尺寸</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1093"/>
        <source>Use Custom Document Size</source>
        <translation>自定义文档显示的尺寸</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1105"/>
        <source>Stop Loading</source>
        <translation>停止载入</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1108"/>
        <source>Stop Loading Web Page</source>
        <translation>停止载入网页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1122"/>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1134"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1146"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1162"/>
        <source>Sleep</source>
        <translation>睡眠</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1165"/>
        <source>Put Presentation to Sleep</source>
        <translation>使演示屏进入睡眠状态</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1178"/>
        <source>Virtual Keyboard</source>
        <translation>虚拟键盘</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1181"/>
        <source>Display Virtual Keyboard</source>
        <translation>打开虚拟键盘</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1199"/>
        <location filename="../forms/mainWindow.ui" line="1205"/>
        <source>Plain Light Background</source>
        <translation>白色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1202"/>
        <location filename="../forms/mainWindow.ui" line="1221"/>
        <location filename="../forms/mainWindow.ui" line="1240"/>
        <location filename="../forms/mainWindow.ui" line="1259"/>
        <source>Light</source>
        <translation>白色</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1218"/>
        <location filename="../forms/mainWindow.ui" line="1224"/>
        <source>Grid Light Background</source>
        <translation>白色网格背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1275"/>
        <location filename="../forms/mainWindow.ui" line="1281"/>
        <source>Plain Dark Background</source>
        <translation>黑色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1278"/>
        <location filename="../forms/mainWindow.ui" line="1297"/>
        <location filename="../forms/mainWindow.ui" line="1316"/>
        <location filename="../forms/mainWindow.ui" line="1335"/>
        <source>Dark</source>
        <translation>黑色</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1294"/>
        <location filename="../forms/mainWindow.ui" line="1300"/>
        <source>Grid Dark Background</source>
        <translation>黑色网格背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1350"/>
        <source>Podcast</source>
        <translation>播客</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1353"/>
        <source>Record Presentation to Video</source>
        <translation>将演示录制为视频</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1366"/>
        <source>Record</source>
        <translation>录制</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1369"/>
        <source>Start Screen Recording</source>
        <translation>开始屏幕录制</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1378"/>
        <source>Erase Items</source>
        <translation>擦除项目</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1381"/>
        <source>Erase All Items</source>
        <translation>擦除所有项目</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1390"/>
        <location filename="../forms/mainWindow.ui" line="1831"/>
        <source>Erase Annotations</source>
        <translation>擦除标注</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1393"/>
        <source>Erase All Annotations</source>
        <translation>擦除所有标注</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1402"/>
        <source>Clear Page</source>
        <translation>清空页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1405"/>
        <source>Clear All Elements</source>
        <translation>清空所有内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1430"/>
        <source>Pen</source>
        <translation>笔</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1433"/>
        <source>Annotate Document</source>
        <translation>标注文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1972"/>
        <source>Snap to grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1975"/>
        <source>Snap to grid and angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1978"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation type="vanished">Ctrl+I</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1452"/>
        <source>Erase Annotation</source>
        <translation>擦除批注</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1455"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1468"/>
        <source>Marker</source>
        <translation>记号笔</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1471"/>
        <source>Highlight </source>
        <translation>高亮</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1474"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1487"/>
        <source>Selector</source>
        <translation>选择工具</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1490"/>
        <source>Select And Modify Objects</source>
        <translation>选中并修改对象</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1493"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1506"/>
        <source>Hand</source>
        <translation>手型工具</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1509"/>
        <source>Scroll Page</source>
        <translation>滚动页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1548"/>
        <source>Laser Pointer</source>
        <translation>激光笔</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1551"/>
        <source>Virtual Laser Pointer</source>
        <translation>虚拟激光笔</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1554"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1570"/>
        <source>Draw Lines</source>
        <translation>画线</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1573"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1586"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1589"/>
        <source>Write Text</source>
        <translation>输入文本</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1592"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1605"/>
        <source>Capture</source>
        <translation>截图</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1608"/>
        <location filename="../forms/mainWindow.ui" line="1773"/>
        <source>Capture Part of the Screen</source>
        <translation>部分屏幕截图</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1617"/>
        <location filename="../forms/mainWindow.ui" line="1620"/>
        <source>Add To Current Page</source>
        <translation>添加到当前页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1623"/>
        <source>Add Item To Current Page</source>
        <translation>将项目添加到当前打开的页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1632"/>
        <source>Add To New Page</source>
        <translation>添加到新页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1635"/>
        <source>Add Item To New Page</source>
        <translation>将项目添加到新页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1644"/>
        <source>Add To Library</source>
        <translation>添加到库</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1647"/>
        <source>Add Item To Library</source>
        <translation>将项目添加到库</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1659"/>
        <source>Pages</source>
        <translation>页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1662"/>
        <location filename="../forms/mainWindow.ui" line="1679"/>
        <source>Create a New Page</source>
        <translation>新建页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1676"/>
        <source>New Page</source>
        <translation>新页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1688"/>
        <source>Duplicate Page</source>
        <translation>复制页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1691"/>
        <source>Duplicate the Current Page</source>
        <translation>复制当前打开的页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1700"/>
        <source>Import Page</source>
        <translation>导入页面</translation>
    </message>
    <message>
        <source>Import an External Page</source>
        <translation type="vanished">导入外部页面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1718"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1721"/>
        <source>Pause Podcast Recording</source>
        <translation>暂停录制播客</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1730"/>
        <source>Podcast Config</source>
        <translation>播客设置</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1733"/>
        <source>Configure Podcast Recording</source>
        <translation>播客录制设置</translation>
    </message>
    <message>
        <source>Flash Trap</source>
        <translation type="vanished">截取动画</translation>
    </message>
    <message>
        <source>Trap Flash Content</source>
        <translation type="vanished">截取动画内容</translation>
    </message>
    <message>
        <source>Web Trap</source>
        <translation type="vanished">截取网页</translation>
    </message>
    <message>
        <source>Trap Web Content</source>
        <translation type="vanished">截取网页内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1770"/>
        <source>Custom Capture</source>
        <translation>自定义截图</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1782"/>
        <source>Window Capture</source>
        <translation>窗口截图</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1785"/>
        <source>Capture a Window</source>
        <translation>截取一个窗口</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1797"/>
        <source>Embed Web Content</source>
        <translation>嵌入网页内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1800"/>
        <source>Capture Embeddable Web Content</source>
        <translation>截取可嵌入的网页内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1813"/>
        <source>Show on Display</source>
        <translation>在屏幕上显示</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1816"/>
        <source>Show Main Screen on Display Screen</source>
        <translation>在显示屏上显示主屏幕</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1834"/>
        <source>Erase all Annotations</source>
        <translation>擦除所有标注</translation>
    </message>
    <message>
        <source>eduMedia</source>
        <translation type="vanished">eduMedia</translation>
    </message>
    <message>
        <source>Import eduMedia simulation</source>
        <translation type="vanished">导入 eduMedia 模拟</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1843"/>
        <source>Check Update</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1858"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="14"/>
        <location filename="../forms/mainWindow.ui" line="727"/>
        <location filename="../forms/mainWindow.ui" line="730"/>
        <source>OpenBoard</source>
        <translation>OpenBoard</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="411"/>
        <source>Quit OpenBoard</source>
        <translation>退出 OpenBoard</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1852"/>
        <source>Hide OpenBoard</source>
        <translation>隐藏 OpenBoard</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1855"/>
        <source>Hide OpenBoard Application</source>
        <translation>隐藏 OpenBoard 应用程序</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1871"/>
        <source>Play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1874"/>
        <source>Interact with items</source>
        <translation>与项目互动</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1883"/>
        <source>Erase Background</source>
        <translation>擦除背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1886"/>
        <source>Remove the backgound</source>
        <translation>删除背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1237"/>
        <location filename="../forms/mainWindow.ui" line="1243"/>
        <source>Ruled Light Background</source>
        <translation>有条纹的浅色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1313"/>
        <location filename="../forms/mainWindow.ui" line="1319"/>
        <source>Ruled Dark Background</source>
        <translation>有条纹的深色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1895"/>
        <source>Open Tutorial</source>
        <translation>打开教程</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1898"/>
        <source>Open the tutorial web page</source>
        <translation>打开教程网页</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1907"/>
        <location filename="../forms/mainWindow.ui" line="1910"/>
        <source>Reset grid size</source>
        <translation>重置网格大小</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="432"/>
        <source>Small Eraser</source>
        <translation>小橡皮擦</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="477"/>
        <location filename="../forms/mainWindow.ui" line="480"/>
        <source>Color 1</source>
        <translation>颜色 1</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="495"/>
        <location filename="../forms/mainWindow.ui" line="498"/>
        <source>Color 2</source>
        <translation>颜色 2</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="513"/>
        <location filename="../forms/mainWindow.ui" line="516"/>
        <source>Color 3</source>
        <translation>颜色 3</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="531"/>
        <location filename="../forms/mainWindow.ui" line="534"/>
        <source>Color 4</source>
        <translation>颜色 4</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="549"/>
        <location filename="../forms/mainWindow.ui" line="552"/>
        <source>Color 5</source>
        <translation>颜色 5</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1923"/>
        <location filename="../forms/mainWindow.ui" line="1926"/>
        <source>Draw intermediate grid lines</source>
        <translation>绘制中间网格线</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1742"/>
        <location filename="../forms/mainWindow.ui" line="1745"/>
        <location filename="../forms/mainWindow.ui" line="1758"/>
        <location filename="../forms/mainWindow.ui" line="1761"/>
        <source>Capture Web Content</source>
        <translation>捕获网页内容</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="323"/>
        <source>Documents Mode</source>
        <translation>文档模式</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="343"/>
        <source>Web Mode</source>
        <translation>网络模式</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="483"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="501"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="519"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="537"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="555"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="660"/>
        <source>Board Mode</source>
        <translation>白板模式</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="753"/>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="756"/>
        <source>Desktop Mode</source>
        <translation>桌面模式</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="938"/>
        <source>Add to document</source>
        <translation>添加到文档</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1256"/>
        <location filename="../forms/mainWindow.ui" line="1262"/>
        <source>Seyes ruled Light Background</source>
        <translation>窥视有条纹的亮色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1332"/>
        <location filename="../forms/mainWindow.ui" line="1338"/>
        <source>Seyes ruled Dark Background</source>
        <translation>窥视有条纹的暗色背景</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1436"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1703"/>
        <source>Import one or more pages (supported formats : jpg, png, svg, ubz, pdf)</source>
        <translation>导入一个或多个页面（支持的格式：jpg、png、svg、ubz、pdf）</translation>
    </message>
    <message>
        <source>Add to favorites</source>
        <translation type="vanished">添加到收藏夹</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1942"/>
        <source>Add Document to favorites</source>
        <translation>将文档添加到收藏夹</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1956"/>
        <source>Hints and tips</source>
        <translation>提示与技巧</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1959"/>
        <source>Open Hints and tips</source>
        <translation>打开提示与技巧</translation>
    </message>
    <message>
        <location filename="../forms/mainWindow.ui" line="1939"/>
        <source>Favorite</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../../src/web/simplebrowser/passworddialog.ui" line="14"/>
        <source>Authentication Required</source>
        <translation>需要验证</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/passworddialog.ui" line="46"/>
        <source>Username:</source>
        <translation>用户名：</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/passworddialog.ui" line="56"/>
        <source>Password:</source>
        <translation>密码：</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/passworddialog.ui" line="20"/>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/passworddialog.ui" line="36"/>
        <source>Info</source>
        <translation>信息</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../plugins/cffadaptor/src/UBCFFAdaptor.cpp" line="1181"/>
        <source>Element ID = </source>
        <translation>元素 ID = </translation>
    </message>
    <message>
        <location filename="../../plugins/cffadaptor/src/UBCFFAdaptor.cpp" line="1183"/>
        <source>Content is not supported in destination format.</source>
        <translation>目标格式不支持该内容。</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBDocumentThumbnailsView.cpp" line="880"/>
        <location filename="../../src/gui/UBDocumentThumbnailsView.cpp" line="1007"/>
        <source>Remove Page</source>
        <translation>删除页面</translation>
    </message>
    <message>
        <source>Are you sure you want to remove 1 page from the selected document &apos;%0&apos;?</source>
        <translation type="vanished">确定要从选中的文件“%0”中删除1页吗？</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBSvgSubsetAdaptor.cpp" line="247"/>
        <source>Loading scene (%1/%2)</source>
        <translation>加载场景 (%1/%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/UBSceneCache.cpp" line="243"/>
        <source>Moving cached scenes (%1/%2)</source>
        <translation>移动已缓存场景 (%1/%2)</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBDocumentThumbnailsView.cpp" line="881"/>
        <location filename="../../src/gui/UBDocumentThumbnailsView.cpp" line="1008"/>
        <source>Are you sure you want to remove page %1 ?</source>
        <translation>确定要删除页面 %1 吗？</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="46"/>
        <source>Common</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabWidget</name>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="123"/>
        <source>New &amp;Tab</source>
        <translation>新建标签页（&amp;T）</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="126"/>
        <source>Clone Tab</source>
        <translation>复制标签页</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="131"/>
        <source>&amp;Close Tab</source>
        <translation>关闭标签页（&amp;C）</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="136"/>
        <source>Close &amp;Other Tabs</source>
        <translation>关闭其它标签页（&amp;O）</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="141"/>
        <source>Reload Tab</source>
        <translation>刷新标签页</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="149"/>
        <source>Reload All Tabs</source>
        <translation>刷新所有标签页</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/tabwidget.cpp" line="223"/>
        <source>(Untitled)</source>
        <translation>空白页</translation>
    </message>
</context>
<context>
    <name>UBApplication</name>
    <message>
        <location filename="../../src/core/UBApplication.cpp" line="569"/>
        <source>Page Size</source>
        <translation>页面大小</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplication.cpp" line="590"/>
        <source>Podcast</source>
        <translation>播客</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplication.cpp" line="356"/>
        <location filename="../../src/core/UBApplication.cpp" line="402"/>
        <location filename="../../src/core/UBApplication.cpp" line="645"/>
        <source>Cannot open your UBX file directly. Please import it in Documents mode instead</source>
        <translation>无法直接打开 UBX 文件。请以文档模式导入</translation>
    </message>
</context>
<context>
    <name>UBApplicationController</name>
    <message>
        <location filename="../../src/core/UBApplicationController.cpp" line="341"/>
        <source>Web</source>
        <translation>网页</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplicationController.cpp" line="586"/>
        <source>New update available, would you go to the web page ?</source>
        <translation>有可用的更新，是否登陆更新页面？</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplicationController.cpp" line="592"/>
        <source>No update available</source>
        <translation>无可用的更新</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplicationController.cpp" line="586"/>
        <source>Update available</source>
        <translation>有可用的更新</translation>
    </message>
    <message>
        <location filename="../../src/core/UBApplicationController.cpp" line="592"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
</context>
<context>
    <name>UBBackgroundPalette</name>
    <message>
        <location filename="../../src/gui/UBBackgroundPalette.cpp" line="49"/>
        <source>Grid size</source>
        <translation>网格大小</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBBackgroundPalette.cpp" line="50"/>
        <source>Draw intermediate grid lines</source>
        <translation>绘制中间网格线</translation>
    </message>
</context>
<context>
    <name>UBBoardController</name>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1198"/>
        <source>Downloading content %1 failed</source>
        <translation>下载内容 %1 失败</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1207"/>
        <source>Download finished</source>
        <translation>下载已完成</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1534"/>
        <source>Unknown tool type %1</source>
        <translation>未知工具类型 %1</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1579"/>
        <source>Unknown content type %1</source>
        <translation>未知内容类型 %1</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="2723"/>
        <source>Add Item</source>
        <translation>添加项目</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="2725"/>
        <source>All Supported (%1)</source>
        <translation>所有支持的（%1）</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="865"/>
        <source>Page %1 deleted</source>
        <translation>已删除 %1 页</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1338"/>
        <location filename="../../src/board/UBBoardController.cpp" line="1383"/>
        <location filename="../../src/board/UBBoardController.cpp" line="2328"/>
        <location filename="../../src/board/UBBoardController.cpp" line="2364"/>
        <source>Add file operation failed: file copying error</source>
        <translation>增加操作失败文档：文件复制错误</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="112"/>
        <source>Group</source>
        <translation>组合</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="113"/>
        <source>Ungroup</source>
        <translation>取消组合</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="486"/>
        <source>Saving document...</source>
        <translation>正在保存文档……</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="492"/>
        <source>Document has just been saved...</source>
        <translation>文档刚刚保存……</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="847"/>
        <source>Deleting page %1</source>
        <translation>正在删除页面 %1</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="362"/>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1547"/>
        <source>Untitled</source>
        <translation>无标题</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardController.cpp" line="1574"/>
        <source>Could not find document.</source>
        <translation>找不到文档。</translation>
    </message>
</context>
<context>
    <name>UBBoardPaletteManager</name>
    <message>
        <location filename="../../src/board/UBBoardPaletteManager.cpp" line="948"/>
        <source>Error Adding Image to Library</source>
        <translation>添加图片到库时出错</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardPaletteManager.cpp" line="943"/>
        <source>CapturedImage</source>
        <translation>抓取图像</translation>
    </message>
</context>
<context>
    <name>UBBoardThumbnailsView</name>
    <message>
        <source>Loading page (%1/%2)</source>
        <translation type="obsolete">下载加载页面 (%1/%2)</translation>
    </message>
</context>
<context>
    <name>UBBoardView</name>
    <message>
        <location filename="../../src/board/UBBoardView.cpp" line="1774"/>
        <source>Is it for Board or Widget ?</source>
        <translation>用于白板还是小部件？</translation>
    </message>
    <message>
        <location filename="../../src/board/UBBoardView.cpp" line="1775"/>
        <source>Are you trying to drop the object(s) inside the widget ?</source>
        <translation>想要拖拽小部件中的对象吗？</translation>
    </message>
</context>
<context>
    <name>UBCachePropertiesWidget</name>
    <message>
        <location filename="../../src/gui/UBCachePropertiesWidget.cpp" line="81"/>
        <source>Cache Properties</source>
        <translation>缓存属性</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBCachePropertiesWidget.cpp" line="95"/>
        <source>Color:</source>
        <translation>颜色：</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBCachePropertiesWidget.cpp" line="106"/>
        <source>Shape:</source>
        <translation>形状：</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBCachePropertiesWidget.cpp" line="125"/>
        <source>Size:</source>
        <translation>大小：</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBCachePropertiesWidget.cpp" line="136"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>UBDesktopPalette</name>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="69"/>
        <source>Capture Part of the Screen</source>
        <translation>局部截图</translation>
    </message>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="73"/>
        <source>Capture the Screen</source>
        <translation>全屏截图</translation>
    </message>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="94"/>
        <source>Show the stylus palette</source>
        <translation>显示工具面板</translation>
    </message>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="143"/>
        <source>Show Board on Secondary Screen</source>
        <translation>在第二屏幕显示白板</translation>
    </message>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="145"/>
        <source>Show Desktop on Secondary Screen</source>
        <translation>在第二屏幕显示桌面</translation>
    </message>
    <message>
        <location filename="../../src/desktop/UBDesktopPalette.cpp" line="55"/>
        <source>Show OpenBoard</source>
        <translation>显示 OpenBoard</translation>
    </message>
</context>
<context>
    <name>UBDocumentController</name>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2025"/>
        <source>New Folder</source>
        <translation>新建文件夹</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="4181"/>
        <source>Page %1</source>
        <translation>页面 %1</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2197"/>
        <source>Add Folder of Images</source>
        <translation>添加图片文件夹</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2198"/>
        <source>Add Images</source>
        <translation>添加图片</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2199"/>
        <source>Add Pages from File</source>
        <translation>从文件添加页面</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2489"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="2501"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3466"/>
        <source>Opening document in Board. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2507"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3472"/>
        <source>Document opened successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2566"/>
        <source>Duplicating Document %1</source>
        <translation>正在复制文档 %1</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2570"/>
        <source>Document %1 copied</source>
        <translation>已复制文档 %1</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3275"/>
        <source>Open Supported File</source>
        <translation>打开支持的文件</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3185"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3290"/>
        <source>Importing file %1...</source>
        <translation>导入文件 %1 ……</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3194"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3332"/>
        <source>Failed to import file ... </source>
        <translation>导入文件失败 ……</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3221"/>
        <source>Import all Images from Folder</source>
        <translation>导入文件夹中的全部图片</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3873"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3874"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3894"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3895"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3888"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3889"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3900"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3901"/>
        <source>Empty</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="1933"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3848"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3849"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3869"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3870"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3905"/>
        <location filename="../../src/document/UBDocumentController.cpp" line="3906"/>
        <source>Trash</source>
        <translation>回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3574"/>
        <source>Open Document</source>
        <translation>打开文档</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3630"/>
        <source>Add all Images to Document</source>
        <translation>将所有图片添加到文档</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3631"/>
        <source>All Images (%1)</source>
        <translation>所有图像（%1）</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3661"/>
        <source>Selection does not contain any image files!</source>
        <translation>选中的对象不包含任何图片文件！</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3253"/>
        <source>Folder does not contain any image files</source>
        <translation>文件夹中没有图像文件</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="1934"/>
        <source>Untitled Documents</source>
        <translation>未命名文档</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/document/UBDocumentController.cpp" line="2556"/>
        <source>duplicated %1 page</source>
        <comment>duplicated %1 pages</comment>
        <translation>
            <numerusform>重复 %1 页面</numerusform>
        </translation>
    </message>
    <message>
        <source>Remove Item</source>
        <translation type="obsolete">删除项目</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected item(s) ?</source>
        <translation type="obsolete">确定要删除所选项目吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3575"/>
        <source>The document &apos;%1&apos; has been generated with a newer version of OpenBoard (%2). By opening it, you may lose some information. Do you want to proceed?</source>
        <translation>已使用较新版本的 OpenBoard (%2) 生成文档“%1”。打开它，可能会丢失一些信息。 想要继续吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="4183"/>
        <source>Title page</source>
        <translation>标题页面</translation>
    </message>
    <message>
        <source>Refreshing Document Thumbnails View (%1/%2)</source>
        <translation type="vanished">刷新文档缩略图视图 (%1/%2)</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2613"/>
        <source>Complete deletion of %1 documents/folders</source>
        <translation>完全删除 %1 个文档/文件夹</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2614"/>
        <source>You are about to permanantly delete %1 documents and/or folders. Are you sure ?</source>
        <translation>永久删除 %1 个文档或/和文件夹。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2698"/>
        <source>Complete deletion of folder &quot;%1&quot;</source>
        <translation>完全删除文件夹&quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2699"/>
        <source>You are about to permanantly delete folder &quot;%1&quot;. Are you sure ?</source>
        <translation>永久删除文件夹&quot;%1&quot;。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2704"/>
        <source>Complete deletion of document &quot;%1&quot;</source>
        <translation>完全删除文档&quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2705"/>
        <source>You are about to permanantly delete document &quot;%1&quot;. Are you sure ?</source>
        <translation>永久删除文档&quot;%1&quot;。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2722"/>
        <source>Emptying My Documents</source>
        <translation>清空我的文档</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2723"/>
        <source>You are about to entirely empty the folder &quot;My Documents&quot;. All your documents will be moved to trash. Are you sure ?</source>
        <translation>整个清空&quot;My Documents&quot;文件夹。其中所有的文档将被移到回收站。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2759"/>
        <source>Emptying Trash</source>
        <translation>清空回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2760"/>
        <source>You are about to entirely empty the trash. All documents and folders in it will be permanently deleted. Are you sure ?</source>
        <translation>清空回收站。其中的所有文件和文件夹都将被永久删除。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2776"/>
        <source>Moving %1 elements to trash</source>
        <translation>正在移动%1个项目到回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2777"/>
        <source>You are about to move %1 documents and/or folders to trash. Are you sure ?</source>
        <translation>将%1个文档或/和文件夹移到回收站。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2785"/>
        <source>Move folder &quot;%1&quot;to trash</source>
        <translation>将文件夹&quot;%1&quot;移到回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2786"/>
        <source>You are about to move folder &quot;%1&quot; to trash. Are you sure ?</source>
        <translation>将文件夹&quot;%1&quot;移到回收站。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2792"/>
        <source>Move document &quot;%1&quot;to trash</source>
        <translation>将文档&quot;%1&quot;移到回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="2793"/>
        <source>You are about to move document &quot;%1&quot; to trash. Are you sure ?</source>
        <translation>将文档&quot;%1&quot;移到回收站。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3145"/>
        <source>Open Supported File(s)</source>
        <translation>打开支持的文件</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3404"/>
        <source>Refreshing Document Thumbnails View (%1 pages)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3408"/>
        <source>Refreshing Document Thumbnails View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3412"/>
        <source>Document Thumbnails View up-to-date. Repainting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3972"/>
        <source>Moving %1 pages of the document &quot;%2&quot; to trash</source>
        <translation>将文档&quot;%2&quot;的%1个页面移到回收站</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3973"/>
        <source>You are about to move %1 pages of the document &quot;%2&quot; to trash. Are you sure ?</source>
        <translation>将文档&quot;%2&quot;的%1个页面移到回收站。确定吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3979"/>
        <source>Remove page %1</source>
        <translation>删除页面%1</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="3980"/>
        <source>You are about to remove page %1 of the document &quot;%2&quot;. Are you sure ?</source>
        <translation>删除文档&quot;%2&quot;的页面 %1。确定吗？</translation>
    </message>
</context>
<context>
    <name>UBDocumentManager</name>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="75"/>
        <source>images</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="76"/>
        <source>videos</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="77"/>
        <source>objects</source>
        <translation>素材</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="78"/>
        <source>widgets</source>
        <translation>小部件</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="132"/>
        <source>All supported files (*.%1)</source>
        <translation>所有支持的文件（*.%1）</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="216"/>
        <source>Creating %1 pages. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="338"/>
        <source>File %1 saved</source>
        <translation>文件 %1 已保存</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="287"/>
        <source>Inserting page %1 of %2</source>
        <translation>插入第 %1 页，共 %2 页</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="230"/>
        <source>Import successful.</source>
        <translation>导入成功。</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="295"/>
        <source>Import of file %1 successful.</source>
        <translation>文件 %1 导入成功。</translation>
    </message>
    <message>
        <location filename="../../src/core/UBDocumentManager.cpp" line="248"/>
        <source>Importing file %1</source>
        <translation>正在导入文件 %1</translation>
    </message>
</context>
<context>
    <name>UBDocumentNavigator</name>
    <message>
        <source>Page %0</source>
        <translation type="vanished">页面 %0</translation>
    </message>
    <message>
        <source>Generating thumbnails for board (%1/%2)</source>
        <translation type="obsolete">为白板生成缩略图 (%1/%2)</translation>
    </message>
</context>
<context>
    <name>UBDocumentReplaceDialog</name>
    <message>
        <source>Accept</source>
        <translation type="obsolete">接受</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="113"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="112"/>
        <source>Replace</source>
        <translation>替换</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="192"/>
        <source>The name %1 is allready used.
Keeping this name will replace the document.
Providing a new name will create a new document.</source>
        <translation>名称 %1 已被使用。
坚持使用此名称将以当前文档替换原文档。
提供新名称将创建一个新文档。</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="111"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="140"/>
        <source>Replace all</source>
        <translation>全部替换</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="141"/>
        <source>Skip</source>
        <translation>跳过</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="142"/>
        <source>Skip all</source>
        <translation>全部跳过</translation>
    </message>
</context>
<context>
    <name>UBDocumentTreeModel</name>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="401"/>
        <source>Trash</source>
        <translation>回收站</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/document/UBDocumentController.cpp" line="757"/>
        <source>%1 pages copied</source>
        <translation>
            <numerusform>已复制 %1 个页面</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="397"/>
        <source>My documents</source>
        <translation>我的文档</translation>
    </message>
</context>
<context>
    <name>UBDocumentTreeView</name>
    <message numerus="yes">
        <location filename="../../src/document/UBDocumentController.cpp" line="1713"/>
        <source>%1 pages copied</source>
        <translation>
            <numerusform>已复制 %1 个页面</numerusform>
        </translation>
    </message>
    <message>
        <source>Remove Item</source>
        <translation type="obsolete">删除项目</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the selected item(s) ?</source>
        <translation type="obsolete">您确定要删除所选项目吗？</translation>
    </message>
    <message>
        <location filename="../../src/document/UBDocumentController.cpp" line="1657"/>
        <source>Copying page %1/%2</source>
        <translation>正在复制页面 %1/%2</translation>
    </message>
</context>
<context>
    <name>UBDownloadWidget</name>
    <message>
        <location filename="../../src/gui/UBDownloadWidget.cpp" line="55"/>
        <source>Downloading files</source>
        <translation>下载文件</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBDownloadWidget.cpp" line="74"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>UBDraggableLivePixmapItem</name>
    <message>
        <location filename="../../src/gui/UBDocumentThumbnailsView.h" line="593"/>
        <location filename="../../src/gui/UBDocumentThumbnailsView.h" line="596"/>
        <location filename="../../src/gui/UBDocumentThumbnailsView.h" line="598"/>
        <source>Page %0</source>
        <translation>页面 %0</translation>
    </message>
</context>
<context>
    <name>UBDraggableThumbnail</name>
    <message>
        <source>Page %0</source>
        <translation type="obsolete">页面 %0</translation>
    </message>
</context>
<context>
    <name>UBDraggableThumbnailView</name>
    <message>
        <source>Page %0</source>
        <translation type="obsolete">页面 %0</translation>
    </message>
</context>
<context>
    <name>UBEmbedController</name>
    <message>
        <location filename="../../src/web/UBEmbedController.cpp" line="73"/>
        <source>Whole page</source>
        <translation>整个页面</translation>
    </message>
    <message>
        <location filename="../../src/web/UBEmbedController.cpp" line="236"/>
        <source>Web</source>
        <translation>网页</translation>
    </message>
    <message>
        <location filename="../../src/web/UBEmbedController.cpp" line="165"/>
        <source>Application name can`t contain any of the following characters:<byte value="xd"/>
</source>
        <translation>应用名称不能包含以下字符：<byte value="xd"/></translation>
    </message>
</context>
<context>
    <name>UBExportAdaptor</name>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="171"/>
        <source>Warnings during export was appeared</source>
        <translation>导出过程中出现警告</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="128"/>
        <source>Exporting document...</source>
        <translation>正在导出文档……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="136"/>
        <source>Export failed</source>
        <translation>导出失败</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="137"/>
        <source>Unable to export to the selected location. You do not have the permissions necessary to save the file.</source>
        <translation>无法导出到所选位置。您没有保存文件所需的权限。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="142"/>
        <source>Export failed: location not writable</source>
        <translation>导出失败：位置不可写入</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportAdaptor.cpp" line="152"/>
        <source>Export successful.</source>
        <translation>导出成功。</translation>
    </message>
</context>
<context>
    <name>UBExportCFF</name>
    <message>
        <location filename="../../src/adaptors/UBExportCFF.cpp" line="53"/>
        <source>Export to IWB</source>
        <translation>导出到 IWB</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportCFF.cpp" line="68"/>
        <source>Export as IWB File</source>
        <translation>导出为 IWB 文件</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportCFF.cpp" line="75"/>
        <source>Exporting document...</source>
        <translation>正在导出文档……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportCFF.cpp" line="81"/>
        <source>Export successful.</source>
        <translation>导出成功。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportCFF.cpp" line="85"/>
        <source>Export failed.</source>
        <translation>导出失败。</translation>
    </message>
</context>
<context>
    <name>UBExportDocument</name>
    <message>
        <location filename="../../src/adaptors/UBExportDocument.cpp" line="55"/>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocument.cpp" line="65"/>
        <source>Export as UBZ File</source>
        <translation>以 UBZ 文件格式导出</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocument.cpp" line="104"/>
        <source>Exporting %1 %2 of %3</source>
        <translation>正在导出 %3 的 %1 %2</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocument.cpp" line="116"/>
        <source>Export to OpenBoard Format</source>
        <translation>导出为 OpenBoard 格式</translation>
    </message>
</context>
<context>
    <name>UBExportDocumentSetAdaptor</name>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="99"/>
        <source>Exporting document...</source>
        <translation>正在导出文档……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="75"/>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="84"/>
        <source>Failed to export...</source>
        <translation>导出失败……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="78"/>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="91"/>
        <source>Export as UBX File</source>
        <translation>导出为 UBX 文件</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="103"/>
        <source>Export successful.</source>
        <translation>导出成功。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="107"/>
        <source>Export failed.</source>
        <translation>导出失败。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportDocumentSetAdaptor.cpp" line="153"/>
        <source>Export to OpenBoard UBX Format</source>
        <translation>导出为 OpenBoard UBX 格式</translation>
    </message>
</context>
<context>
    <name>UBExportFullPDF</name>
    <message>
        <location filename="../../src/adaptors/UBExportFullPDF.cpp" line="185"/>
        <source>Export as PDF File</source>
        <translation>导出为 PDF 文件</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportFullPDF.cpp" line="363"/>
        <source>Export to PDF</source>
        <translation>以PDF文件格式导出</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportFullPDF.cpp" line="313"/>
        <location filename="../../src/adaptors/UBExportFullPDF.cpp" line="327"/>
        <source>The original PDF imported in OpenBoard seems not valid and could not be merged with your annotations. Please repair it and then reimport it in OpenBoard. The current export will be done with detailed (heavy) images of the pages of the original PDF instead, to avoid complete export failure.</source>
        <translation>导入的PDF文件似乎无效，不能与您的批注合并。请修复后将其重新导入 OpenBoard。当前的导出将以原PDF页面的详细（重）图像代替页面文本，以避免导出失败。</translation>
    </message>
</context>
<context>
    <name>UBExportPDF</name>
    <message>
        <location filename="../../src/adaptors/UBExportPDF.cpp" line="67"/>
        <source>Export as PDF File</source>
        <translation>导出为 PDF 文件</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportPDF.cpp" line="105"/>
        <source>Exporting page %1 of %2</source>
        <translation>正在导出页面 %1/%2</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportPDF.cpp" line="165"/>
        <source>Export to PDF</source>
        <translation>导出为 PDF</translation>
    </message>
</context>
<context>
    <name>UBExportWeb</name>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="50"/>
        <source>Page</source>
        <translation>页面</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="65"/>
        <source>Export as Web data</source>
        <translation>作为网页数据导出</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="70"/>
        <source>Exporting document...</source>
        <translation>正在导出文档……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="79"/>
        <source>Export successful.</source>
        <translation>导出成功。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="85"/>
        <source>Export failed.</source>
        <translation>导出失败。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBExportWeb.cpp" line="96"/>
        <source>Export to Web Browser</source>
        <translation>导出到网络浏览器</translation>
    </message>
</context>
<context>
    <name>UBFeatureProperties</name>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="902"/>
        <source>Add to page</source>
        <translation>添加到页面</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="906"/>
        <source>Add to library</source>
        <translation>添加至库</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="911"/>
        <source>Object informations</source>
        <translation>对象信息</translation>
    </message>
</context>
<context>
    <name>UBFeaturesActionBar</name>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="71"/>
        <source>Add to favorites</source>
        <translation>添加到收藏夹</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="73"/>
        <source>Share</source>
        <translation>分享</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="74"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="76"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="77"/>
        <source>Back to folder</source>
        <translation>返回文件夹</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="72"/>
        <source>Remove from favorites</source>
        <translation>从收藏夹中移除</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="78"/>
        <source>Create new folder</source>
        <translation>新建文件夹</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesActionBar.cpp" line="75"/>
        <source>Rescan file system</source>
        <translation>重新扫描文件系统</translation>
    </message>
</context>
<context>
    <name>UBFeaturesController</name>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="915"/>
        <location filename="../../src/board/UBFeaturesController.cpp" line="1044"/>
        <source>ImportedImage</source>
        <translation>已导入图片</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="337"/>
        <source>Audios</source>
        <translation>音频</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="338"/>
        <source>Movies</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="339"/>
        <source>Pictures</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="341"/>
        <source>Interactivities</source>
        <translation>互动</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="342"/>
        <source>Applications</source>
        <translation>应用程序</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="343"/>
        <source>Shapes</source>
        <translation>形状</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="344"/>
        <source>Favorites</source>
        <translation>收藏夹</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="345"/>
        <source>Web search</source>
        <translation>网络搜索</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="347"/>
        <source>Trash</source>
        <translation>回收站</translation>
    </message>
    <message>
        <location filename="../../src/board/UBFeaturesController.cpp" line="741"/>
        <location filename="../../src/board/UBFeaturesController.cpp" line="747"/>
        <source>Web</source>
        <translation type="unfinished">网页</translation>
    </message>
</context>
<context>
    <name>UBFeaturesNewFolderDialog</name>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="657"/>
        <source>Accept</source>
        <translation>接受</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="658"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="659"/>
        <source>Enter a new folder name</source>
        <translation>输入新的文件夹名称</translation>
    </message>
</context>
<context>
    <name>UBFeaturesProgressInfo</name>
    <message>
        <location filename="../../src/gui/UBFeaturesWidget.cpp" line="762"/>
        <source>Loading </source>
        <translation>正在载入</translation>
    </message>
</context>
<context>
    <name>UBGraphicsGroupContainerItemDelegate</name>
    <message>
        <location filename="../../src/domain/UBGraphicsGroupContainerItemDelegate.cpp" line="57"/>
        <source>Locked</source>
        <translation>已锁定</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsGroupContainerItemDelegate.cpp" line="64"/>
        <source>Visible on Extended Screen</source>
        <translation>在扩展屏幕上可见</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsGroupContainerItemDelegate.cpp" line="72"/>
        <source>Hide on Extended Screen when selected</source>
        <translation>选中时，在扩展屏幕上隐藏</translation>
    </message>
</context>
<context>
    <name>UBGraphicsItemDelegate</name>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="788"/>
        <source>Locked</source>
        <translation>已位置</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="795"/>
        <source>Visible on Extended Screen</source>
        <translation>在扩展屏幕上可见</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="811"/>
        <source>Set as background</source>
        <translation>设置为背景</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="821"/>
        <source>Web Inspector</source>
        <translation>网页检查器</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="803"/>
        <source>Hide on Extended Screen when selected</source>
        <translation>选中时，在扩展屏幕上隐藏</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="204"/>
        <source>Duplicate</source>
        <translation type="unfinished">复制</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="218"/>
        <source>Layer up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsItemDelegate.cpp" line="227"/>
        <source>Layer down</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBGraphicsMediaItem</name>
    <message>
        <location filename="../../src/domain/UBGraphicsMediaItem.cpp" line="490"/>
        <source>Media resource couldn&apos;t be resolved</source>
        <translation>无法解析媒体资源</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsMediaItem.cpp" line="493"/>
        <source>Unsupported media format</source>
        <translation>不支持的媒体格式</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsMediaItem.cpp" line="497"/>
        <source>Media playback service not found</source>
        <translation>未找到媒体播放服务</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsMediaItem.cpp" line="500"/>
        <location filename="../../src/domain/UBGraphicsMediaItem.cpp" line="503"/>
        <source>Media error: </source>
        <translation>媒体错误：</translation>
    </message>
</context>
<context>
    <name>UBGraphicsProtractor</name>
    <message>
        <location filename="../../src/tools/UBGraphicsProtractor.cpp" line="535"/>
        <source>use arrow keys for precise moves</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBGraphicsRuler</name>
    <message>
        <location filename="../../src/tools/UBGraphicsRuler.cpp" line="167"/>
        <location filename="../../src/tools/UBGraphicsRuler.cpp" line="171"/>
        <source>use arrow keys for precise moves</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBGraphicsTextItem</name>
    <message>
        <location filename="../../src/domain/UBGraphicsTextItem.cpp" line="49"/>
        <source>&lt;Type Text Here&gt;</source>
        <translation>&lt;在此输入文本&gt;</translation>
    </message>
</context>
<context>
    <name>UBGraphicsTextItemDelegate</name>
    <message>
        <location filename="../../src/domain/UBGraphicsTextItemDelegate.cpp" line="338"/>
        <source>Text Color</source>
        <translation>文本颜色</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsTextItemDelegate.cpp" line="472"/>
        <source>Editable</source>
        <translation>可编辑</translation>
    </message>
</context>
<context>
    <name>UBGraphicsTriangle</name>
    <message>
        <location filename="../../src/tools/UBGraphicsTriangle.cpp" line="449"/>
        <location filename="../../src/tools/UBGraphicsTriangle.cpp" line="453"/>
        <source>use arrow keys for precise moves</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBGraphicsW3CWidgetItem</name>
    <message>
        <location filename="../../src/domain/UBGraphicsWidgetItem.cpp" line="1241"/>
        <source>Web</source>
        <translation>网页</translation>
    </message>
</context>
<context>
    <name>UBGraphicsWidgetItem</name>
    <message>
        <location filename="../../src/domain/UBGraphicsWidgetItem.cpp" line="830"/>
        <source>Loading ...</source>
        <translation>正在载入……</translation>
    </message>
</context>
<context>
    <name>UBGraphicsWidgetItemDelegate</name>
    <message>
        <location filename="../../src/domain/UBGraphicsWidgetItemDelegate.cpp" line="89"/>
        <source>Frozen</source>
        <translation>锁定</translation>
    </message>
    <message>
        <location filename="../../src/domain/UBGraphicsWidgetItemDelegate.cpp" line="101"/>
        <source>Transform as Tool </source>
        <translation>转换为工具</translation>
    </message>
</context>
<context>
    <name>UBImportCFF</name>
    <message>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="81"/>
        <source>Common File Format (</source>
        <translation>常见文件格式 (</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="103"/>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="246"/>
        <source>Importing file %1...</source>
        <translation>正在导入文件 %1……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="117"/>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="262"/>
        <source>Import of file %1 failed.</source>
        <translation>文件 %1 导入失败。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="133"/>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="290"/>
        <source>Import successful.</source>
        <translation>导入成功。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="139"/>
        <location filename="../../src/adaptors/UBImportCFF.cpp" line="295"/>
        <source>Import failed.</source>
        <translation>导入失败。</translation>
    </message>
</context>
<context>
    <name>UBImportDocument</name>
    <message>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="180"/>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="200"/>
        <source>Importing file %1...</source>
        <translation>正在导入文件 %1 ……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="219"/>
        <source>Import successful.</source>
        <translation>导入成功。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="188"/>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="207"/>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="213"/>
        <source>Import of file %1 failed.</source>
        <translation>文件 %1 导入失败。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportDocument.cpp" line="73"/>
        <source>OpenBoard (*.ubz)</source>
        <translation>OpenBoard (*.ubz)</translation>
    </message>
</context>
<context>
    <name>UBImportDocumentSetAdaptor</name>
    <message>
        <location filename="../../src/adaptors/UBImportDocumentSetAdaptor.cpp" line="71"/>
        <source>Openboard (set of documents) (*.ubx)</source>
        <translation>Openboard (文件集) (*.ubx)</translation>
    </message>
</context>
<context>
    <name>UBImportImage</name>
    <message>
        <location filename="../../src/adaptors/UBImportImage.cpp" line="74"/>
        <source>Image Format (</source>
        <translation>图片格式</translation>
    </message>
</context>
<context>
    <name>UBImportPDF</name>
    <message>
        <location filename="../../src/adaptors/UBImportPDF.cpp" line="63"/>
        <source>Portable Document Format (*.pdf)</source>
        <translation>便携文档格式（*.pdf）</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportPDF.cpp" line="75"/>
        <source>PDF import failed.</source>
        <translation>PDF 导入失败。</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBImportPDF.cpp" line="81"/>
        <source>Importing %1 PDF pages. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing page %1 of %2</source>
        <translation type="vanished">正在导入第 %1 页，共 %2 页</translation>
    </message>
</context>
<context>
    <name>UBIntranetPodcastPublisher</name>
    <message>
        <location filename="../../src/podcast/intranet/UBIntranetPodcastPublisher.cpp" line="185"/>
        <source>Error while publishing video to intranet (%1)</source>
        <translation>视频发布到内网过程中出错 (%1)</translation>
    </message>
    <message>
        <location filename="../../src/podcast/intranet/UBIntranetPodcastPublisher.cpp" line="196"/>
        <source>Publishing to Intranet in progress %1 %</source>
        <translation>正在发布到内网 %1 %</translation>
    </message>
</context>
<context>
    <name>UBIntranetPodcastPublishingDialog</name>
    <message>
        <location filename="../../src/podcast/intranet/UBIntranetPodcastPublisher.cpp" line="215"/>
        <source>Publish</source>
        <translation>发布</translation>
    </message>
</context>
<context>
    <name>UBKeyboardPalette</name>
    <message>
        <location filename="../../src/gui/UBKeyboardPalette_linux.cpp" line="173"/>
        <location filename="../../src/gui/UBKeyboardPalette_win.cpp" line="87"/>
        <source>Enter</source>
        <translation>输入</translation>
    </message>
</context>
<context>
    <name>UBMainWindow</name>
    <message>
        <location filename="../../src/gui/UBMainWindow.cpp" line="205"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBMainWindow.cpp" line="206"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBMainWindow.cpp" line="231"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>UBMessagesDialog</name>
    <message>
        <location filename="../../src/gui/UBMessagesDialog.cpp" line="60"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>UBNetworkAccessManager</name>
    <message>
        <location filename="../../src/network/UBNetworkAccessManager.cpp" line="108"/>
        <source>&lt;qt&gt;Enter username and password for &quot;%1&quot; at %2&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;在 %2 输入“%1”的用户名和密码&lt;/qt&gt;</translation>
    </message>
    <message>
        <location filename="../../src/network/UBNetworkAccessManager.cpp" line="140"/>
        <source>Failed to log to Proxy</source>
        <translation>连接代理服务器失败</translation>
    </message>
    <message>
        <location filename="../../src/network/UBNetworkAccessManager.cpp" line="168"/>
        <source>SSL Errors:

%1

%2

Do you want to ignore these errors for this host?</source>
        <translation>SSL 错误：

%1

%2

忽略该服务器的这些问题吗？</translation>
    </message>
    <message>
        <location filename="../../src/network/UBNetworkAccessManager.cpp" line="170"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/network/UBNetworkAccessManager.cpp" line="171"/>
        <source>No</source>
        <translation>否</translation>
    </message>
</context>
<context>
    <name>UBOpenSankoreImporterWidget</name>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>Open-Sankore Documents Detected</source>
        <translation type="vanished">检测到 Open-Sankore 文档</translation>
    </message>
    <message>
        <source>Open-Sankoré documents are present on your computer. It is possible to import them to OpenBoard by pressing the “Proceed” button to launch the importer application.</source>
        <translation type="vanished">Open-Sankoré 文档存在于您的计算机上。点击“继续“按钮可启动导入器程序，将其导入 OpenBoard。</translation>
    </message>
    <message>
        <source>Show this panel next time</source>
        <translation type="vanished">下次显示此面板</translation>
    </message>
    <message>
        <source>You can always access the OpenBoard Document Importer through the Preferences panel in the About tab. Warning, if you have already imported your Open-Sankore datas, you might loose your current OpenBoard documents.</source>
        <translation type="vanished">通过“关于”选项卡中的“首选项”面板，可随时访问 OpenBoard 文档导入器。 警告，如果已经导入了 Open-Sankore 数据，可能会丢失当前的 OpenBoard 文档。</translation>
    </message>
    <message>
        <source>Proceed</source>
        <translation type="vanished">继续</translation>
    </message>
</context>
<context>
    <name>UBPersistenceManager</name>
    <message>
        <location filename="../../src/core/UBPersistenceManager.cpp" line="742"/>
        <source>(copy)</source>
        <translation>（复制）</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPersistenceManager.cpp" line="1408"/>
        <source>Document Repository Loss</source>
        <translation>文档库丢失</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPersistenceManager.cpp" line="1408"/>
        <source>OpenBoard has lost access to the document repository &apos;%1&apos;. Unfortunately the application must shut down to avoid data corruption. Latest changes may be lost as well.</source>
        <translation>OpenBoard 已失去对文档库“%1”的访问权限。 不幸的是，为避免数据损坏，应用程序必须关闭。 最新的更改也可能会丢失。</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPersistenceManager.cpp" line="1161"/>
        <source>Renaming pages (%1/%2)</source>
        <translation>重命名页面 (%1/%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPersistenceManager.cpp" line="231"/>
        <source>Retrieving all your documents (found : %1)</source>
        <translation>检索所有文档（找到：%1）</translation>
    </message>
</context>
<context>
    <name>UBPlatformUtils</name>
    <message>
        <location filename="../../src/frameworks/UBPlatformUtils_linux.cpp" line="462"/>
        <location filename="../../src/frameworks/UBPlatformUtils_win.cpp" line="429"/>
        <source>English</source>
        <translation>英语</translation>
    </message>
    <message>
        <location filename="../../src/frameworks/UBPlatformUtils_linux.cpp" line="463"/>
        <location filename="../../src/frameworks/UBPlatformUtils_win.cpp" line="430"/>
        <source>Russian</source>
        <translation>俄语</translation>
    </message>
    <message>
        <location filename="../../src/frameworks/UBPlatformUtils_linux.cpp" line="464"/>
        <location filename="../../src/frameworks/UBPlatformUtils_win.cpp" line="433"/>
        <source>German</source>
        <translation>德语</translation>
    </message>
    <message>
        <location filename="../../src/frameworks/UBPlatformUtils_linux.cpp" line="465"/>
        <location filename="../../src/frameworks/UBPlatformUtils_win.cpp" line="431"/>
        <source>French</source>
        <translation>法语</translation>
    </message>
    <message>
        <location filename="../../src/frameworks/UBPlatformUtils_linux.cpp" line="466"/>
        <location filename="../../src/frameworks/UBPlatformUtils_win.cpp" line="432"/>
        <source>Swiss French</source>
        <translation>瑞士法语</translation>
    </message>
</context>
<context>
    <name>UBPodcastController</name>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="399"/>
        <source>Failed to start encoder ...</source>
        <translation>编码器启动失败……</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="404"/>
        <source>No Podcast encoder available ...</source>
        <translation>没有可用的播客编码器……</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="531"/>
        <source>Part %1</source>
        <translation>部分 %1</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="682"/>
        <source>on your desktop ...</source>
        <translation>在桌面上……</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="686"/>
        <source>in folder %1</source>
        <translation>在文件夹 %1 中</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="689"/>
        <source>Podcast created %1</source>
        <translation>已创建播客 %1</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="708"/>
        <source>Podcast recording error (%1)</source>
        <translation>播客录制错误（%1）</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="860"/>
        <source>Default Audio Input</source>
        <translation>默认音频输入</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="863"/>
        <source>No Audio Recording</source>
        <translation>无音频录制</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="902"/>
        <source>Small</source>
        <translation>小</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="903"/>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="904"/>
        <source>Full</source>
        <translation>大</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="939"/>
        <source>Publish to Intranet</source>
        <translation>发布到内网</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="946"/>
        <source>Publish to Youtube</source>
        <translation>发布到 Youtube</translation>
    </message>
    <message>
        <location filename="../../src/podcast/UBPodcastController.cpp" line="371"/>
        <source>OpenBoard Cast</source>
        <translation>OpenBoard 演示表</translation>
    </message>
</context>
<context>
    <name>UBPreferencesController</name>
    <message>
        <location filename="../../src/core/UBPreferencesController.cpp" line="155"/>
        <source>version: </source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPreferencesController.cpp" line="284"/>
        <source>Marker is pressure sensitive</source>
        <translation>使用压感记号笔</translation>
    </message>
    <message>
        <location filename="../../src/core/UBPreferencesController.cpp" line="113"/>
        <source>Use all available displays</source>
        <translation>使用所有可用的显示</translation>
    </message>
</context>
<context>
    <name>UBSettings</name>
    <message>
        <location filename="../../src/core/UBSettings.cpp" line="1022"/>
        <source>My Movies</source>
        <translation>我的视频</translation>
    </message>
</context>
<context>
    <name>UBShortcutManager</name>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="120"/>
        <source>Common</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="136"/>
        <source>Board</source>
        <translation type="unfinished">白板</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="151"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="170"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="173"/>
        <source>Stylus Palette</source>
        <translation type="unfinished">工具面板</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="175"/>
        <source>Lines and colours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="189"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="201"/>
        <source>Podcast</source>
        <translation type="unfinished">播客</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="224"/>
        <source>First scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="225"/>
        <source>Show first scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="231"/>
        <source>Last scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="232"/>
        <source>Show last scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="259"/>
        <source>Zoom reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="260"/>
        <source>Reset zoom factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="266"/>
        <source>Scroll left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="267"/>
        <source>Scroll page left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="273"/>
        <source>Scroll right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="274"/>
        <source>Scroll page right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="280"/>
        <source>Scroll up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="281"/>
        <source>Scroll page up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="287"/>
        <source>Scroll down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="288"/>
        <source>Scroll page down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="293"/>
        <source>Built-in (not editable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="466"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="469"/>
        <source>Description</source>
        <translation type="unfinished">详情</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="472"/>
        <source>Key Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="475"/>
        <source>Mouse Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="478"/>
        <source>Tablet Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="629"/>
        <source>Left</source>
        <comment>MouseButton</comment>
        <translation type="unfinished">向左</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="630"/>
        <source>Right</source>
        <comment>MouseButton</comment>
        <translation type="unfinished">向右</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="631"/>
        <source>Middle</source>
        <comment>MouseButton</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="632"/>
        <source>Back</source>
        <comment>MouseButton</comment>
        <translation type="unfinished">后退</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="633"/>
        <source>Forward</source>
        <comment>MouseButton</comment>
        <translation type="unfinished">前进</translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="634"/>
        <source>Task</source>
        <comment>MouseButton</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/UBShortcutManager.cpp" line="635"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="636"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="637"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="638"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="639"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="640"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="641"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="642"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="643"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="644"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="645"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="646"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="647"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="648"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="649"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="650"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="651"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="652"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="653"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="654"/>
        <location filename="../../src/core/UBShortcutManager.cpp" line="655"/>
        <source>Extra</source>
        <comment>MouseButton</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBStartupHintsPalette</name>
    <message>
        <location filename="../../src/gui/UBStartupHintsPalette.cpp" line="67"/>
        <source>Visible next time</source>
        <translation>下次显示</translation>
    </message>
</context>
<context>
    <name>UBTeacherBarWidget</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UBThumbnailAdaptor</name>
    <message>
        <location filename="../../src/adaptors/UBThumbnailAdaptor.cpp" line="74"/>
        <source>Generating preview thumbnails ...</source>
        <translation>正在生成预览缩略图……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBThumbnailAdaptor.cpp" line="80"/>
        <source>%1 thumbnails generated ...</source>
        <translation>%1 缩略图已生成……</translation>
    </message>
    <message>
        <location filename="../../src/adaptors/UBThumbnailAdaptor.cpp" line="107"/>
        <source>Loading thumbnails (%1 pages)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading thumbnail (%1/%2)</source>
        <translation type="vanished">加载缩略图 (%1/%2)</translation>
    </message>
</context>
<context>
    <name>UBThumbnailTextItem</name>
    <message>
        <location filename="../../src/gui/UBDocumentThumbnailsView.h" line="219"/>
        <location filename="../../src/gui/UBDocumentThumbnailsView.h" line="261"/>
        <source>Page %0</source>
        <translation>页面 %0</translation>
    </message>
</context>
<context>
    <name>UBToolsManager</name>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="57"/>
        <source>Mask</source>
        <translation>幕布</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="65"/>
        <source>Ruler</source>
        <translation>直尺</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="81"/>
        <source>Compass</source>
        <translation>圆规</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="89"/>
        <source>Protractor</source>
        <translation>量角器</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="97"/>
        <source>Triangle</source>
        <translation>三角尺</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="105"/>
        <source>Magnifier</source>
        <translation>放大镜</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="113"/>
        <source>Cache</source>
        <translation>缓存</translation>
    </message>
    <message>
        <location filename="../../src/tools/UBToolsManager.cpp" line="73"/>
        <source>Axes</source>
        <translation>坐标轴</translation>
    </message>
</context>
<context>
    <name>UBUpdateDlg</name>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="64"/>
        <source>Document updater</source>
        <translation>文档更新器</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="69"/>
        <source> files require an update.</source>
        <translation>文件需要更新</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="76"/>
        <source>Backup path: </source>
        <translation>备份路径：</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="82"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="94"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="180"/>
        <source>Select a backup folder</source>
        <translation>选择备份文件夹</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="201"/>
        <source>Files update successful!
Please reboot the application to access the updated documents.</source>
        <translation>文件更新成功！
要打开已更新的文件，请重新启动程序。</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="204"/>
        <source>An error occured during the update. The files have not been affected.</source>
        <translation>更新过程中出错。文件未被改动。</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="206"/>
        <source>Files update results</source>
        <translation>文件更新结果</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="216"/>
        <source>Updating file </source>
        <translation>正在更新文件</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="187"/>
        <source>Please wait the import process will start soon...</source>
        <translation>请等待，导入过程即将开始……</translation>
    </message>
    <message>
        <location filename="../../src/gui/UBUpdateDlg.cpp" line="95"/>
        <source>Remind me later</source>
        <translation>稍后提醒</translation>
    </message>
</context>
<context>
    <name>UBWebEngineView</name>
    <message>
        <location filename="../../src/domain/UBWebEngineView.cpp" line="109"/>
        <source>Open Web Inspector</source>
        <translation>打开网页检查器</translation>
    </message>
</context>
<context>
    <name>UBYouTubePublisher</name>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="152"/>
        <source>YouTube authentication failed.</source>
        <translation>Youtube 验证失败。</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="252"/>
        <source>Error while uploading video to YouTube (%1)</source>
        <translation>视频上传到 Youtube 过程中发生错误（%1）</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="317"/>
        <source>Upload to YouTube in progress %1 %</source>
        <translation>正在上传到 Youtube  %1 %</translation>
    </message>
</context>
<context>
    <name>UBYouTubePublishingDialog</name>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="354"/>
        <source>Upload</source>
        <translation>上传</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="400"/>
        <source>Autos &amp; Vehicles</source>
        <translation>汽车</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="401"/>
        <source>Music</source>
        <translation>音乐</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="402"/>
        <source>Pets &amp; Animals</source>
        <translation>宠物和动物</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="403"/>
        <source>Sports</source>
        <translation>体育与运动</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="404"/>
        <source>Travel &amp; Events</source>
        <translation>旅行与活动</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="405"/>
        <source>Gaming</source>
        <translation>游戏</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="406"/>
        <source>Comedy</source>
        <translation>喜剧</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="407"/>
        <source>People &amp; Blogs</source>
        <translation>人物与博客</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="408"/>
        <source>News &amp; Politics</source>
        <translation>新闻与政治</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="409"/>
        <source>Entertainment</source>
        <translation>娱乐</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="410"/>
        <source>Education</source>
        <translation>教育</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="411"/>
        <source>Howto &amp; Style</source>
        <translation>HowTo 与时尚</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="412"/>
        <source>Nonprofits &amp; Activism</source>
        <translation>非营利与行动主义</translation>
    </message>
    <message>
        <location filename="../../src/podcast/youtube/UBYouTubePublisher.cpp" line="413"/>
        <source>Science &amp; Technology</source>
        <translation>科学与技术</translation>
    </message>
</context>
<context>
    <name>UBZLayerController</name>
    <message>
        <location filename="../../src/domain/UBGraphicsScene.cpp" line="205"/>
        <source>Bottom layer limit reached</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UBZoomPalette</name>
    <message>
        <location filename="../../src/gui/UBZoomPalette.cpp" line="116"/>
        <source>%1 x</source>
        <translation>%1x</translation>
    </message>
</context>
<context>
    <name>WBHistoryModel</name>
    <message>
        <location filename="../../src/web/simplebrowser/WBHistory.cpp" line="470"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/WBHistory.cpp" line="471"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
</context>
<context>
    <name>WBHistoryTreeModel</name>
    <message>
        <location filename="../../src/web/simplebrowser/WBHistory.cpp" line="1046"/>
        <source>Earlier Today</source>
        <translation>今日早些时候</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/WBHistory.cpp" line="1051"/>
        <source>%1 items</source>
        <translation>%1 个项目</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="110"/>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="119"/>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="136"/>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="140"/>
        <source>Certificate Error</source>
        <translation>证书错误</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="159"/>
        <source>Enter username and password for &quot;%1&quot; at %2</source>
        <translation>请输入%2上&quot;%1&quot;的用户名和密码</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="177"/>
        <source>Allow %1 to access your location information?</source>
        <translation>允许 %1 访问位置信息吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="179"/>
        <source>Allow %1 to access your microphone?</source>
        <translation>允许 %1 访问麦克风吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="181"/>
        <source>Allow %1 to access your webcam?</source>
        <translation>允许 %1 访问摄像头吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="183"/>
        <source>Allow %1 to access your microphone and webcam?</source>
        <translation>允许 %1 访问麦克风和摄像头吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="185"/>
        <source>Allow %1 to lock your mouse cursor?</source>
        <translation>允许 %1 锁定光标吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="187"/>
        <source>Allow %1 to capture video of your desktop?</source>
        <translation>允许 %1 捕捉桌面视频吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="189"/>
        <source>Allow %1 to capture audio and video of your desktop?</source>
        <translation>允许 %1 捕捉桌面视频和音频吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="202"/>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="249"/>
        <source>Permission Request</source>
        <translation>权限请求</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="230"/>
        <source>Connect to proxy &quot;%1&quot; using:</source>
        <translation>连接到代理服务器&quot;%1&quot;，使用：</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webpage.cpp" line="250"/>
        <source>Allow %1 to open all %2 links?</source>
        <translation>允许 %1 打开所有 %2 的链接吗？</translation>
    </message>
</context>
<context>
    <name>WebView</name>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="107"/>
        <source>Render process normal exit</source>
        <translation>渲染进程正常退出</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="110"/>
        <source>Render process abnormal exit</source>
        <translation>渲染进程异常退出</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="113"/>
        <source>Render process crashed</source>
        <translation>渲染进程崩溃</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="116"/>
        <source>Render process killed</source>
        <translation>渲染进程被杀死</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="120"/>
        <source>Render process exited with code: %1
Do you want to reload the page ?</source>
        <translation>渲染进程已退出，代码：%1
想要重新载入页面吗？</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="241"/>
        <source>Open Web Inspector in new window</source>
        <translation>在新窗口中打开网页检查器</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="247"/>
        <source>Inspect element</source>
        <translation>检查元件</translation>
    </message>
    <message>
        <location filename="../../src/web/simplebrowser/webview.cpp" line="295"/>
        <source>Add to board</source>
        <translation>添加到白板</translation>
    </message>
</context>
<context>
    <name>XPDFRenderer</name>
    <message>
        <location filename="../../src/pdf/XPDFRenderer.cpp" line="334"/>
        <source>Processing...</source>
        <translation>正在处理……</translation>
    </message>
    <message>
        <location filename="../../src/pdf/XPDFRenderer.cpp" line="79"/>
        <source>an error occured while trying to open the PDF file</source>
        <translation>打开PDF文件时出错</translation>
    </message>
</context>
<context>
    <name>YouTubePublishingDialog</name>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="17"/>
        <source>Publish Podcast to YouTube</source>
        <translation>发布播客到 Youtube</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="28"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="42"/>
        <source>Description</source>
        <translation>详情</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="65"/>
        <source>Keywords</source>
        <translation>关键词</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="79"/>
        <source>Category</source>
        <translation>类别</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="105"/>
        <source>YouTube Username</source>
        <translation>Youtube 用户名</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="115"/>
        <source>YouTube Password</source>
        <translation>Youtube 密码</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="129"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt;&quot;&gt;By clicking &apos;Upload,&apos; you certify that you own all rights to the content or that you are authorized by the owner to make the content publicly available on YouTube, and that it otherwise complies with the YouTube Terms of Service located at &lt;/span&gt;&lt;a href=&quot;http://www.youtube.com/t/terms&quot;&gt;&lt;span style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.youtube.com/t/terms&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt;&quot;&gt;点击“上传”，即表示您证明您拥有该内容的所有权利，或者您已获得所有者的授权，可以在 YouTube 上公开发布该内容，并且该内容符合位于以下网址的 YouTube 服务条款 &lt;/span&gt;&lt;a href=&quot;http://www.youtube.com/t/terms&quot;&gt;&lt;span style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.youtube.com/t/terms&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="72"/>
        <source>OpenBoard</source>
        <translation>OpenBoard</translation>
    </message>
    <message>
        <location filename="../forms/youTubePublishingDialog.ui" line="156"/>
        <source>Restore credentials on reboot</source>
        <translation>重新启动时恢复凭据</translation>
    </message>
</context>
<context>
    <name>brushProperties</name>
    <message>
        <location filename="../forms/brushProperties.ui" line="167"/>
        <source>On Light Background</source>
        <translation>白色背景</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="228"/>
        <source>On Dark Background</source>
        <translation>黑色背景</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="98"/>
        <source>Opacity</source>
        <translation>透明度</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="276"/>
        <source>Line Width</source>
        <translation>线宽</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="336"/>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="362"/>
        <source>Strong</source>
        <translation>粗</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="454"/>
        <source>Fine</source>
        <translation>细</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="53"/>
        <source>Pen is Pressure Sensitive</source>
        <translation>使用压感笔</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="504"/>
        <source>Show preview circle from</source>
        <translation>显示来自此处的预览圈：</translation>
    </message>
    <message>
        <location filename="../forms/brushProperties.ui" line="514"/>
        <source>px</source>
        <translation>px</translation>
    </message>
</context>
<context>
    <name>capturePublishingDialog</name>
    <message>
        <location filename="../forms/capturePublishing.ui" line="17"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="../forms/capturePublishing.ui" line="28"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../forms/capturePublishing.ui" line="42"/>
        <source>E-mail</source>
        <translation>电子邮箱</translation>
    </message>
    <message>
        <location filename="../forms/capturePublishing.ui" line="52"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="../forms/capturePublishing.ui" line="62"/>
        <source>Description</source>
        <translation>详情</translation>
    </message>
</context>
<context>
    <name>documents</name>
    <message>
        <location filename="../forms/documents.ui" line="26"/>
        <source>OpenBoard Documents</source>
        <translation>OpenBoard 文档</translation>
    </message>
    <message>
        <location filename="../forms/documents.ui" line="90"/>
        <source>Creation date</source>
        <translation>创建日期</translation>
    </message>
    <message>
        <location filename="../forms/documents.ui" line="95"/>
        <source>Update date</source>
        <translation>更新日期</translation>
    </message>
    <message>
        <location filename="../forms/documents.ui" line="100"/>
        <source>Alphabetical order</source>
        <translation>按字母顺序</translation>
    </message>
    <message>
        <location filename="../forms/documents.ui" line="130"/>
        <source>Sort Order</source>
        <translation>排序</translation>
    </message>
</context>
<context>
    <name>preferencesDialog</name>
    <message>
        <location filename="../forms/preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="20"/>
        <source>version : …</source>
        <translation>版本：……</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="48"/>
        <source>Default Settings</source>
        <translation>默认设置</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="70"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="89"/>
        <source>Display</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="984"/>
        <source>Internet</source>
        <translation>网页浏览</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="992"/>
        <source>Show Page with External Browser</source>
        <translation>在外部浏览器中显示页面</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="1013"/>
        <source>Home Page:</source>
        <translation>主页：</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="196"/>
        <source>Virtual Keyboard</source>
        <translation>虚拟键盘</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="351"/>
        <source>Toolbar</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="389"/>
        <source>Positioned at the Top (recommended for tablets)</source>
        <translation>总在顶层（平板电脑推荐）</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="382"/>
        <source>Positioned at the Bottom (recommended for white boards)</source>
        <translation>总在底层（电子白板推荐）</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="373"/>
        <source>Display Text Under Button</source>
        <translation>在按钮下显示文字</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="429"/>
        <source>Stylus Palette</source>
        <translation>工具面板</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="455"/>
        <source>Horizontal</source>
        <translation>横向</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="465"/>
        <source>Vertical</source>
        <translation>纵向</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="938"/>
        <source>Pen</source>
        <translation>笔</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="955"/>
        <source>Marker</source>
        <translation>记号笔</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="3212"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="3261"/>
        <source>Software Update</source>
        <translation>软件更新</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="3276"/>
        <source>Check software update at launch</source>
        <translation>启动时检查更新</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="1103"/>
        <source>Licences</source>
        <translation>许可证</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="972"/>
        <source>Network</source>
        <translation>网络连接</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="647"/>
        <source>Show internal web page content on secondary screen or projector</source>
        <translation>在第二屏幕或播放器上显示内部网页内容</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="611"/>
        <source>Multi display</source>
        <translation>多重显示</translation>
    </message>
    <message>
        <source>Swap control display and view display</source>
        <translation type="vanished">交换控制显示和查看显示</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="537"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="545"/>
        <source>Mode to start in:</source>
        <translation>启动模式：</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="553"/>
        <source>Board</source>
        <translation>白板</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="558"/>
        <source>Desktop</source>
        <translation>桌面</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="1020"/>
        <source>Proxy User:</source>
        <translation>Proxy 用户:</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="1048"/>
        <source>Pass:</source>
        <translation>密码：</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="3104"/>
        <source>Credits</source>
        <translation>致谢</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="815"/>
        <source>On Dark Background</source>
        <translation>在深色背景</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="761"/>
        <location filename="../forms/preferences.ui" line="876"/>
        <source>Opacity</source>
        <translation>透明度</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="700"/>
        <source>On Light Background</source>
        <translation>在浅色背景</translation>
    </message>
    <message>
        <source>Swap first and second view displays</source>
        <translation type="obsolete">交换第一和第二视图显示</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="207"/>
        <source>Built-in virtual keyboard button size:</source>
        <translation>内置虚拟键盘按键大小：</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="214"/>
        <source>Use system keyboard (recommended)</source>
        <translation>使用系统键盘（推荐）</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="673"/>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <source>Open-Sankoré Importer</source>
        <translation type="vanished">Open-Sankoré 导入器</translation>
    </message>
    <message>
        <source>Check if Open-Sankoré data could be imported at launch</source>
        <translation type="vanished">检查是否可以在启动时导入 Open-Sankoré 数据</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="267"/>
        <source>Documents Mode</source>
        <translation>文档模式</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="281"/>
        <source>Display date column on alphabetical sort</source>
        <translation>按字母排序显示日期列</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="288"/>
        <source>Empty trash for documents older than</source>
        <translation>清空回收站文档，如果超过：</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="298"/>
        <source>days</source>
        <translation>天</translation>
    </message>
    <message>
        <source>PDF Rendering</source>
        <translation type="obsolete">PDF 渲染</translation>
    </message>
    <message>
        <source>Improve zoom execution time (can slightly affect rendering quality)</source>
        <translation type="vanished">提高缩放执行时间（可能会略微影响渲染质量）</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="128"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="136"/>
        <source>Export background grid</source>
        <translation>导出背景网格</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="143"/>
        <source>Export background color</source>
        <translation>导出背景颜色</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="563"/>
        <source>Documents</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../forms/preferences.ui" line="624"/>
        <source>List of screens used for Control, Display and Previous pages</source>
        <translation>用于控制、显示和上一页的屏幕列表</translation>
    </message>
</context>
<context>
    <name>trapFlashDialog</name>
    <message>
        <source>Trap flash</source>
        <translation type="vanished">截取动画</translation>
    </message>
    <message>
        <source>Select a flash to trap</source>
        <translation type="vanished">选择要截取的动画</translation>
    </message>
    <message>
        <location filename="../forms/trapFlash.ui" line="68"/>
        <source>about:blank</source>
        <translation>关于：空白页</translation>
    </message>
    <message>
        <location filename="../forms/trapFlash.ui" line="84"/>
        <source>Application name</source>
        <translation>应用程序名</translation>
    </message>
    <message>
        <location filename="../forms/trapFlash.ui" line="113"/>
        <source>Create Application</source>
        <translation>创建应用程序</translation>
    </message>
    <message>
        <location filename="../forms/trapFlash.ui" line="22"/>
        <source>Select a content to capture</source>
        <translation>选择要捕获的内容</translation>
    </message>
    <message>
        <location filename="../forms/trapFlash.ui" line="14"/>
        <source>Capture Web Content</source>
        <translation>捕获网页内容</translation>
    </message>
</context>
</TS>
