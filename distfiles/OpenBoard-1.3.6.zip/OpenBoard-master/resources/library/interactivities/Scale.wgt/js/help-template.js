<h3>Scale</h3>
<h4>Equivalent mass, mental calculation</h4>
 
<p> Place weights on the left pan to find the equivalent mass on the right tray. </p>
<p> To add a weight on the left pan, drag and drop it on the pan. </p>
 
<p> Inventory the possibilities on the board or test directly on the scale. </p>
<p> "Reload" button removes the weight shown on the left pan. </p>
 
<p>Enter the "Edit" mode to : </p>
<ul> <li> choose the theme of the App : pad, slate, or none (by default : pad), </li>
<li>determine the mass on the right pan,</li>
<li> determine weights you want to use for the left pane.</li> </ul>

<p> To move a weight in the right tray, drag and drop it on the pane.</p>
<p> To add weight, click the "+" button and enter a mass (don't use decimal numbers). </p>
<p> weights have a field number. Click the box and enter the desired digits. </p>
<p>"Display" button comes back to the activity.</p>
