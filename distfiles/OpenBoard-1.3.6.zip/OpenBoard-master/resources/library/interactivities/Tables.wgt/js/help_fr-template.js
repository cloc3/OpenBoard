<h3>Tables</h3>
<h4>Calcul mental,  propriétés des opérations</h4>

<p>L’interactivité permet de réviser les tables d’addition, de soustraction, de multiplication et de division et de vérifier certaines propriétés.</p>

<p>La flèche sur le tableau indique le sens de lecture.</p>

<p>Le bouton “Recharger” réinitialise l’exercice.</p>

<p>Le bouton "Modifier" vous permet de choisir : </p>
<ul><li>le thème de l’interactivité : tablette, ardoise ou aucun (par défaut tablette),</li>
<li>l’opération souhaitée : addition, soustraction, multiplication ou division,</li>
<li>le nombre de lignes et de colonnes (1 à 12).</li></ul>

<p>Le bouton “Afficher” vous permet d’utiliser l’activité.</p>
