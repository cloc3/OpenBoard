﻿<h3>Počítanie</h3>
<h4>Počítanie spamäti</h4>

<p>V aktivite Počítanie môžete precvičovať všetky matematické úkony (sčítanie, odčítanie, násobenie a&nbsp;delenie). 
Ak chcete zobraziť alebo skryť odpoveď, kliknite na príslušný štvorec v&nbsp;mriežke.</p>

<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav zmeniť:</p>
<ul>
<li> farebný motív na tablet, bridlicu alebo na žiadny (predvolená je bridlica),</li>
<li> matematickú operáciu,</li>
<li> počet riadkov a stĺpcov (1 &ndash; 12).</li>

</ul>
<p>Šípka na doske označuje začiatok príkladu.</p>
<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>