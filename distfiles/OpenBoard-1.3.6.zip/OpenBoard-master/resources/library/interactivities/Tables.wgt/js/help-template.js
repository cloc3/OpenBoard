<h3> Tables</h3>
<h4> Mental calculation, properties of operations </h4>

<p>With the table App you can work on properties of the various operations and review tables of addition, subtraction, multiplication, and division. Click on the case to display or to hide the answer.</p>

<p>The arrow on the board indicates the sense of reading.</p>

<p> Reload "button resets the exercise. </p>


<p> Enter the "Edit" mode to choose the : </p>

<ul> <li>  theme of interactivity : pad, slate or none (by default : pad),</li>
<li> desired operation: addition, subtraction, multiplication or division,</ li>
<li> number of rows and columns (1 to 12). </li> </ul>

<p> "Display" button comes back to the activity.</p>