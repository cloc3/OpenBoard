﻿<h3>Piškvorky</h3>
<h3>variácia na počítanie spamäti</h3>
<p>
Dvaja hráči si na striedačku vyberajú príklady z matematiky, počítajú ich a&nbsp;kontrolujú si ich výsledky.
Na kontrolu výpočtu použite tlačidlo „Skontrolovať“ (fajka). Interaktívna aktivita dokáže príklad skontrolovať sama.
</p>
<p>
Ak je odpoveď správna, pole bude označené krížikom (X) alebo kruhom (O) podľa toho, ktorý hráč je na rade.
Ak je odpoveď nesprávna, na rade je druhý hráč. 
</p>
<p>Označenie hráča sa zobrazí v ľavom hornom rohu: Hráč č. 1 (X), Hráč č. 2 (O).</p>

<p>Hráč, ktorý ako prvý umiestni 3 svoje značky (X alebo O) v riadku za sebou (hore, dole alebo šikmo), je víťaz.</p>

<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav:</p>
<ul>
<li> zmeniť farebný motív na bridlicu, tablet alebo na žiadny (predvolená je bridlica),</li>
<li> zadať vlastné príklady, ktoré chcete použiť vo svojej aktivite.</li>
</ul>
<p>Interaktívna aktivita dokáže rozoznať matematický zápis &ndash; povolené znamienka: „+“, „*“ (krát), „-“, „/“ (delené) a zátvorky.</p>
<p>Tlačidlom „Obnoviť“ znova spustíte hru.</p>
