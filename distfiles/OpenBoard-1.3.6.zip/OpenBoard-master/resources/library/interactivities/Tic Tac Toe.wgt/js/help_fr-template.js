<h3>Morpion</h3>
<h3>Version calcul mental</h3>

<p>
Les deux joueurs choisissent, répondent et font valider tour à tour une opération dans une case.<br/>
Une fois la réponse saisie, la “coche” permet de vérifier la réponse. L’App corrige la réponse.<br/>
Si la réponse est correcte, la case est marquée d’une croix (X) ou d’un cercle (O) selon le joueur.<br/>
Si la réponse est fausse, l’autre joueur prend la main.
</p>
<p>Le nom du joueur figure à gauche : JOUEUR 1 (X), JOUEUR 2 (O).</p>

<p>Le premier joueur qui parvient à aligner trois de ses symboles (X ou O)  gagne la partie.</p>

<p>Le bouton "éditer" vous permet de :</p>
<ul>
	<li>choisir le thème de l'interactivité : tablette, ardoise ou aucun (par défaut tablette),</li>
	<li>modifier les calculs que vous voulez utiliser pour votre activité.</li>
</ul>
<p>L’App est capable d’identifier les écritures mathématiques (signes autorisés : “+”, “*”, “-”, “/” et les parenthèses).</p>

<p>Le bouton "Recharger" permet de recommencer le jeu.</p>
