﻿<h3>Kocky</h3>
<h4>Na počítanie nahlas alebo iné hry</h4>
<p>Interaktívna aktivita Kocky vám umožňuje zobraziť náhodne vybrané steny hracích kociek.</p>
<p>Po kliknutí na šípku alebo na tlačidlo „Hodiť!“  sa zobrazia iné čísla.
So zo&shy;brazenými číslami môžete precvičovať počítanie nahlas alebo hrať iné hry.
</p>
<p>Výpočty a ich postup môžu byť za&shy;písané na interaktívnu tabuľu (mimo interaktívnej aktivity).</p>
 
<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav  zmeniť:</p>
<ul>
<li>farebný motív na bridlicu, tablet alebo na žiadny (predvolená je bridlica),<br></li>
<li>počet kociek, ktoré vo svojej aktivite použijete (2 &ndash; 6).</li>
</ul>
<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>