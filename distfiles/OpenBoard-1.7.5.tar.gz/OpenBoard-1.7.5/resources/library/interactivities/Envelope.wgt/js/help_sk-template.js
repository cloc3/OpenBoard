﻿<h3>Obálka</h3>
<h4>Vyjadrenie množstva</h4>
<p>Kliknite na zopár kancelárskych sponiek a&nbsp;presuňte ich obálky.</p>
<p>Ak ich chcete odtiaľ vybrať, stačí kliknúť na obálku. Sponky z&nbsp;obálky budú mať inú farbu.</p>
<p>Ak chcete znova spustiť hru, kliknite na tlačidlo „Obnoviť“ .</p>

<p>Po stlačení tlačidla „Upraviť“ môžete v&nbsp;režime úprav zmeniť:</p>
<ul>
<li>farebný motív na bridlicu, tablet alebo na žiadny (predvolený je tablet),</li>
<li>počet sponiek.</li>
</ul>
<p>Tlačidlom „Zobraziť“ sa z režimu úprav vrátite na aktivitu.</p>
